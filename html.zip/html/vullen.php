<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="style/normalize.css" />
    <link rel="stylesheet" href="style/smartpet_screen.css" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.2.0/socket.io.js"
        integrity="sha256-yr4fRk/GU1ehYJPAs8P4JlTgu0Hdsp4ZKrx8bDEDC3I=" crossorigin="anonymous"></script>

    <script defer src="script/dataHandler.js"></script>
    <script defer src="script/app.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css"
        integrity="sha256-46r060N2LrChLLb5zowXQ72/iKKNiw/lAmygmHExk/o=" crossorigin="anonymous" />

    <title>SmartPET : Geschiedenis</title>
    <script>

    </script>
</head>

<body class="js-page-vullen">
    <div class="c-page">
        <?php include('menu.html'); ?>
        <!-- Vullen -->
        <section class="o-row o-row--neutral-xx-light">
            <div class="o-container u-max-width-lg">
                <article class="o-section o-section-xl u-mt-xl u-mb-lg">
                    <div class="o-layout o-layout--gutter-lg o-layout--justify-center ">
                        <div class="o-layout__item u-3-of-4-bp3 u-mb-xl">
                            <div class="c-block">
                                <div class="u-max-width-lg">
                                    <div class="c-block__content ">
                                        <h2>Vullen</h2>
                                        <div class="o-layout o-layout--gutter-md">
                                            <div class="o-layout__item u-1-of-2">
                                                <h3>Voederbak</h3>
                                                <input min="1" step="5" type="number" name="add_hoeveelheid"
                                                    id="add_hoeveelheid" required placeholder="Hoeveelheid in gram..">
                                                <button type="submit" name="btn_add_hoeveelheid"
                                                    id="btn_add_hoeveelheid" class="c-button">Voeg toe</button>
                                            </div>
                                            <div class="o-layout__item u-1-of-2">
                                                <h3>Opslag</h3>
                                                <input min="1" step="5" type="number" name="add_opslag"
                                                    id="add_opslag" required placeholder="Hoeveelheid in gram..">
                                                <button type="submit" name="btn_add_opslag"
                                                    id="btn_add_opslag" class="c-button">Voeg toe</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </article>
            </div>
        </section>
        <!-- Aanvullingen -->
        <section class="o-row o-row--neutral-xx-dark">
            <div class="o-container u-max-width-lg">
                <div class="o-container u-max-width-lg">
                    <article class="o-section o-section-xl u-mt-xl u-mb-lg">
                        <div class="o-layout o-layout--gutter-lg o-layout--justify-center ">
                            <div class="o-layout__item u-3-of-4-bp3 u-mb-xl">
                                <div class="c-block">
                                    <div class="u-max-width-lg">
                                        <div class="c-block__content ">

                                            <h2>Aanvullingen deze week</h2>
                                            <h3>Voederbak</h3>

                                            <p class="u-max-width-sm">
                                                <div class="js-fill-history o-layout o-layout--gutter-md">
                                                    
                                                </div>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                    </article>
                </div>

            </div>
        </section>

        <?php include('footer.html'); ?>

    </div>
    <?php include('menu_aside.html'); ?>

</body>
</html>