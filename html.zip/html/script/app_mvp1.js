'use strict';

const backend_IP = `http://${window.location.hostname}:5000`;
console.log(backend_IP);
const backend = backend_IP + '/api/v1';
const socket = io(`${backend_IP}`);

//#region ***  DOM references ***
let html_page_dashboard;
let html_feed_history;

let app_settings;



//#endregion

//#region ***  Callback-Visualisation - show___ ***

const showHistoryPetDay = function (jsonObject) {
	showHistoryPet(jsonObject, "day")
}

const showHistoryPetWeek = function (jsonObject) {
	showHistoryPet(jsonObject, "week")
}

const showHistoryPetMonth = function (jsonObject) {
	showHistoryPet(jsonObject, "month")
}

const showHistoryPetYear = function (jsonObject) {
	showHistoryPet(jsonObject, "year")
}

const showHistoryPet = function (jsonObject, type = "all") {
	let htmlstring_days = '';

	let chartjs_data = {
		"label": [], "dayofweek": [], "hoeveelheid": [], "eatenstatus": [],
	};

	for (const day of jsonObject) {

		let date = new Date(day.meetdatum);


		let eatenStatus = getEatenStatus(day.hoeveelheid);

		let dateFormatted;

		let label;

		if (type == "all") {
			dateFormatted = `${date.getDate()}/${date.getMonth() +
				1}/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
			label = dateFormatted;
		}
		if (type == "day") {
			dateFormatted = `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
			label = dateFormatted;
		} else if (type == "week") {
			dateFormatted = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
			label = getDay(new Date(date).getDay());;
		} else if (type == "month") {
			dateFormatted = `${date.getMonth() + 1}/${date.getFullYear()}`;
			console.log(date);
			label = getMonth(date.getMonth());
		} else if (type == "year") {
			dateFormatted = `${date.getFullYear()}`;
			label = date.getFullYear();
		}




		htmlstring_days += `
		<div data-date="${date}" data-hoeveelheid="${day.hoeveelheid}" class="js-feed-history-day c-foodstatus--${eatenStatus}">${label} : ${day.hoeveelheid}g : ${eatenStatus}</div>
		`;

		chartjs_data.label.push(label);
		chartjs_data.hoeveelheid.push(day.hoeveelheid);
		chartjs_data.eatenstatus.push(eatenStatus);


	}
	console.log(chartjs_data)

	html_feed_history.innerHTML = htmlstring_days;
	listenToHoverOnDay();
	console.log(chartjs_data.label, chartjs_data.hoeveelheid);

	drawChart(chartjs_data.label, chartjs_data.hoeveelheid);
};

const showHistoryPetOnDay = function (jsonObject) { };

const showHistoryFills = function (jsonObject) { };

const showFeedAverage = function (jsonObject) {

	let feed_average = document.querySelector('.js-feed-history-average');
	feed_average.innerHTML = `Gemiddelde per dag ${Math.round(
		jsonObject.avg_hoeveelheid_day,
	)}g`;
};

const showAppName = function () {
	document.querySelector('.js-appname').innerHTML = app_settings.appname;
};

const showDailyGoal = function () {
	document.querySelector('#edit_daily_goal').value = app_settings.daily_goal;
};

const showDailyRange = function () {
	document.querySelector('#edit_daily_range').value =
		app_settings.daily_range;
};


//#endregion

//#region ***  Callback-No Visualisation - callback___  ***
const callbackAddhoeveelheid = function (data) {
	if (data) {
		console.log('Vullen gelukt');
		document.querySelector('#add_hoeveelheid').value = '';
		getHistory();
	}
};

const callbackEditSettings = function (data) {
	if (data) {
		console.log('-- Settings editted');
		app_settings.daily_goal = data.daily_goal;
		app_settings.daily_range = data.daily_range;
		document.querySelector('#edit_daily_goal').value = data.daily_goal;
		document.querySelector('#edit_daily_range').value = data.daily_range;
		getHistory();
	}
};

const callbackEditSettingsError = function (data) {
	console.log('Failed', data);
};

const callbackAppSettings = function (jsonObject) {
	app_settings = jsonObject;

	if (app_settings) {
		showAppName();
		showDailyGoal();
		showDailyRange();
	}
};
//#endregion

//#region ***  Data Access - get___ ***
const getAppSettings = function () {
	handleData(`${backend}/app_settings`, callbackAppSettings);
};

const getHistory = function () {
	handleData(`${backend}/history`, showHistoryPet);
};

const getHistoryDay = function () {
	handleData(`${backend}/history/day`, showHistoryPetDay);
};

const getHistoryWeek = function () {
	handleData(`${backend}/history/week`, showHistoryPetWeek);
};

const getHistoryMonth = function () {
	handleData(`${backend}/history/month`, showHistoryPetMonth);
};

const getHistoryYear = function () {
	handleData(`${backend}/history/month`, showHistoryPetYear);
};

const getHistoryDate = function () {
	handleData(`${backend}/history/month`, showHistoryPetDay);
};

const getFeedAverage = function (days) {
	handleData(`${backend}/feedaverage/${days}`, showFeedAverage);
};

const getEatenStatus = function (hoeveelheid) {
	let goal = parseInt(app_settings.daily_goal);
	let range = parseInt(app_settings.daily_range);

	let status = '';

	if (hoeveelheid >= goal + range * 2) {
		status = 'way-too-much';
	} else if (hoeveelheid < goal + range * 2 && hoeveelheid >= goal + range) {
		status = 'too-much';
	} else if (
		hoeveelheid < goal + range &&
		(hoeveelheid >= goal || hoeveelheid <= goal) &&
		hoeveelheid > goal - range
	) {
		status = 'normal';
	} else if (hoeveelheid <= goal - range && hoeveelheid > goal - range * 2) {
		status = 'too-little';
	} else if (hoeveelheid <= goal - range * 2) {
		status = 'way-too-little';
	}

	return status;
};

const getDay = function (day_number) {
	let days = [
		'Maandag',
		'Dinsdag',
		'Woensdag',
		'Donderdag',
		'Vrijdag',
		'Zaterdag',
		'Zondag',
	];
	return days[day_number];
};

const getMonth = function (month_number) {
	let months = [
		'Januari',
		'Februari',
		'Maart',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Augustus',
		'September',
		'Oktober',
		'November',
		'Decemeber',
	];
	return months[month_number];
};

//#endregion

//#region ***  Event Listeners - listenTo___ ***
const listenToUI = function () { };

const listenToHoverOnDay = function () {
	let history_days = document.querySelectorAll('.js-feed-history-day');

	for (const day of history_days) {
		day.addEventListener('mouseover', function (e) {
			let date = getDay(new Date(day.dataset.date).getDay());
			let hoeveelheid = day.dataset.hoeveelheid;
			let info = document.querySelector('.js-feed-history-info');

			info.innerHTML = `Op ${date} ${hoeveelheid}g`;
		});
	}
};

const loadUIEventListeners = function () {
	document
		.querySelector('#btn_add_hoeveelheid')
		.addEventListener('click', function (e) {
			const jsonObject = {
				hoeveelheid: document.querySelector('#add_hoeveelheid').value,
			};
			console.log(jsonObject);
			handleData(
				`${backend}/add_hoeveelheid`,
				callbackAddhoeveelheid,
				null,
				'POST',
				JSON.stringify(jsonObject),
			);
			socket.emit("F2B_add_hoeveelheid", jsonObject);
		});

	document
		.querySelector('#btn_edit_settings')
		.addEventListener('click', function (e) {
			const jsonObject = {
				daily_goal: document.querySelector('#edit_daily_goal').value,
				daily_range: document.querySelector('#edit_daily_range').value,
			};
			console.log(jsonObject);
			handleData(
				`${backend}/app_settings`,
				callbackEditSettings,
				callbackEditSettingsError,
				'PUT',
				JSON.stringify(jsonObject),
			);
		});
	document
		.querySelector('.js-filter-today')
		.addEventListener('click', function (e) {
			``;
			getHistoryDay();
		});
	document
		.querySelector('.js-filter-week')
		.addEventListener('click', function (e) {
			``;
			getHistoryWeek();
		});
	document
		.querySelector('.js-filter-month')
		.addEventListener('click', function (e) {
			``;
			getHistoryMonth();
		});
	document
		.querySelector('.js-filter-year')
		.addEventListener('click', function (e) {
			``;
			getHistoryYear();
		});
	document
		.querySelector('.js-filter-all')
		.addEventListener('click', function (e) {
			``;
			getHistory();
		});
};

const listenToSocket = function () {
	socket.on("connected", function () {
		console.log("verbonden met socket webserver");
	});
}

//#endregion

//#region ***  INIT / DOMContentLoaded  ***
const init = function () {
	console.log('SmartPET : Project : Maxime Vermeeren');
	html_page_dashboard = document.querySelector('.js-page-dashboard');
	listenToSocket();

	if (html_page_dashboard) {
		getAppSettings();
		html_feed_history = document.querySelector('.js-feed-history');

		if (html_feed_history) {
			getHistory();
			getFeedAverage(30);

		}

		loadUIEventListeners();

	}



};

//#endregion

// ChartJS
const drawChart = function (labels, hoeveelheid_voederbak_data) {

	let ctx = document.querySelector('#myChart').getContext('2d');

	let config = {
		type: 'line', //Type chart
		data: {
			labels: labels, //Labels op de chart tonen
			datasets: [
				{
					label: 'Voederbak', //Hoofdlabel
					backgroundColor: 'rgba(0,0,0,0.05)',
					borderColor: 'red',
					data: hoeveelheid_voederbak_data,
					fill: true,

				},

			],
		},
		options: {
			responsive: true,
			title: {
				display: true,
				text: 'Chart.js Line Chart',
			},
			tooltips: {
				mode: 'index',
				intersect: true,
			},
			hover: {
				mode: 'nearest',
				intersect: true,
			},
			scales: {
				xAxes: [
					{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Dag',

						},
						ticks: {
							fontStyle: 'oblique',
						}

					},
				],
				yAxes: [
					{
						display: true,
						scaleLabel: {
							display: true,
							labelString: 'Waarde',
						},
					},
				],
			},
		},
	};
	let myChart = new Chart(ctx, config);
};

document.addEventListener('DOMContentLoaded', init);
