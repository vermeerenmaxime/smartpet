'use strict';

const backend_IP = `http://${window.location.hostname}:5000`;

const backend = backend_IP + '/api/v1';
const socket = io(`${backend_IP}`);

//#region ***  DOM references ***
let html_page_dashboard, html_page_metingen;

let html_feed_history, html_fill_history, html_metingen, html_wijzigingen;


let app_settings;
//#endregion


function toggleNav() {
	let toggleTrigger = document.querySelectorAll(".js-toggle-nav");
	for (let i = 0; i < toggleTrigger.length; i++) {
		toggleTrigger[i].addEventListener("click", function () {
			console.log("Toggle Mobile Nav");
			document.querySelector("body").classList.toggle("has-mobile-nav");
		})
	}
}


//#region ***  Callback-Visualisation - show___ ***

const showMetingen = function (jsonObject) {
	let htmlstring_metingen = "<tr><th>Sensor</th><th>Hoeveelheid</th><th>Meetdatum</th><th>Actiecode</th></tr>";
	// console.log(jsonObject);
	for (const meting of jsonObject) {
		htmlstring_metingen += `
		<tr>
			<td>${meting.device}</td>
			<td>${meting.hoeveelheid} ${meting.meeteenheid}</td>
			<td>${meting.meetdatum}</td>
			<td>${meting.actiecode}</td>
		</tr>
		`;
	}

	html_metingen.innerHTML = htmlstring_metingen;
}

const showWijzigingen = function (jsonObject) {
	let htmlstring_wijzigingen = `<tr><th>Doel</th><th>Range</th><th>Opslag</th><th>Datum</th></tr>`;

	for (const wijziging of jsonObject) {
		let date = new Date(wijziging.datum);
		
		let	dateFormatted = `${date.getDate()}/${date.getMonth() +
				1}/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;

		htmlstring_wijzigingen += `<tr>
			<td>${wijziging.daily_goal}g</td>
			<td>${wijziging.daily_range}g</td>
			<td>${wijziging.opslag}g</td>
			<td>${dateFormatted}</td>
		</tr>
		`;

	}

	html_wijzigingen.innerHTML = htmlstring_wijzigingen;
}

const showHistoryPetDay = function (jsonObject) {
	showHistoryPet(jsonObject, "day")
}

const showHistoryPetWeek = function (jsonObject) {
	showHistoryPet(jsonObject, "week")
}

const showHistoryPetMonth = function (jsonObject) {
	showHistoryPet(jsonObject, "month")
}

const showHistoryPetYear = function (jsonObject) {
	showHistoryPet(jsonObject, "year")
}



const showHistoryPet = function (jsonObject, type = "all") {
	let htmlstring_days = '';
	// console.log(jsonObject);

	let chartjs_data = {
		"label": [], "dayofweek": [], "hoeveelheid": [], "eatenstatus": [], "label_x": "", "label_y": "", "bordercolor": [], "type": "bar"
	};

	for (const day of jsonObject) {

		let date = new Date(day.meetdatum);

		let eatenStatus = "#3a44a0", dateFormatted, label, label_x, label_y, charttype = "bar";

		if (type == "all") {
			dateFormatted = `${date.getDate()}/${date.getMonth() +
				1}/${date.getFullYear()} ${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
			label = "";
			label_x = "Alle metingen";
			label_y = "Hoeveelheid in gram";
			charttype = "line";
		}
		if (type == "day") {
			// dateFormatted = `${date.getHours()}:${date.getMinutes()}:${date.getSeconds()}`;
			dateFormatted = `${date.getHours()}:${date.getMinutes()}`;
			label = dateFormatted;
			label_x = `Uur van de dag (${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()})`
		} else if (type == "week") {
			dateFormatted = `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
			label = getDay(new Date(date).getDay());
			eatenStatus = getEatenStatus(day.hoeveelheid);
			label_x = "Day";
		} else if (type == "month") {
			dateFormatted = `${date.getMonth() + 1}/${date.getFullYear()}`;

			label = getMonth(date.getMonth());
			label_x = "Maand";
		} else if (type == "year") {
			dateFormatted = `${date.getFullYear()}`;
			label = date.getFullYear();
			label_x = "Jaar";
		}


		// htmlstring_days += `
		// <div data-date="${date}" data-hoeveelheid="${day.hoeveelheid}" class="js-feed-history-day c-foodstatus--${eatenStatus}">${label} : ${day.hoeveelheid}g : ${eatenStatus}</div>
		// `;

		chartjs_data.label.push(label);
		chartjs_data.hoeveelheid.push(day.hoeveelheid);
		chartjs_data.eatenstatus.push(eatenStatus);
		chartjs_data.label_x = label_x;
		chartjs_data.label_y = label_y;
		chartjs_data.bordercolor.push(eatenStatus)
		chartjs_data.type = charttype;

	}

	// html_feed_history.innerHTML = htmlstring_days;
	listenToHoverOnDay();
	//console.log(chartjs_data.label, chartjs_data.hoeveelheid);
	// console.log("hoi");
	drawChart(chartjs_data.label, chartjs_data.hoeveelheid, chartjs_data.label_x, chartjs_data.label_y, chartjs_data.bordercolor, chartjs_data.type);

	// showAlert("Test");
};

const showHistoryPetOnDay = function (jsonObject) { };

const showFillHistory = function (jsonObject) {
	let htmlstring_fills = "";

	for (const fill of jsonObject) {
		let date = new Date(fill.meetdatum);

		let dateFormatted = `${getDay(new Date(date).getDay())} om ${("0" + (date.getHours() + 1)).slice(-2)}:${("0" + (date.getMinutes() + 1)).slice(-2)}`;
		htmlstring_fills += `<div class="o-layout__item u-1-of-4-bp3 u-1-of-3-bp1"><div class="c-bubble"><div class="c-bubble__title">${dateFormatted}</div> ${fill.hoeveelheid} ${fill.meeteenheid}</div></div>`;
	}

	html_fill_history.innerHTML = htmlstring_fills;
};

const showFeedAverage = function (jsonObject) {

	let feed_average = document.querySelectorAll('.js-feed-history-average');
	if (feed_average) {
		for (let feed_average_html of feed_average) {
			feed_average_html.innerHTML = `${Math.round(
				jsonObject.avg_hoeveelheid_day,
			)}g`;
		}

	}

};

const showFeedCountToday = function (jsonObject) {
	let feed_count_day = document.querySelector(".js-feed-count-today");
	if (feed_count_day) {
		feed_count_day.innerHTML = `${jsonObject.count_eats}`;
	}

}

const showAppName = function () {
	let html_appname = document.querySelector('.js-appname');
	if (html_appname) {
		html_appname.innerHTML = app_settings.appname;
	}
};

const showDailyGoal = function () {
	let html_daily_goal = document.querySelector('#edit_daily_goal');
	if (html_daily_goal) {
		document.querySelector('#edit_daily_goal').value = app_settings.daily_goal;
	}

};

const showDailyRange = function () {
	let html_daily_range = document.querySelector('#edit_daily_range');
	if (html_daily_range) {
		html_daily_range.value = app_settings.daily_range;
	}

};

const showOpslag = function () {
	let html_current_stock = document.querySelector('.js-current-stock');
	// console.log("hoi")
	if (html_current_stock) {
		html_current_stock.innerHTML = `${app_settings.opslag} gram`;
	}
}

const showAlert = function (data) {
	let html_alert = document.querySelector(".js-alert");

	if (html_alert) {


		html_alert.style.display = "block";
		let html_alert_info = document.querySelector(".js-alert-info");
		if (html_alert_info) {
			// html_alert_info.innerHTML = "Het lijkt erop dat uw huisdier de laatste dagen te weinig heeft gegeten.";
			html_alert_info.innerHTML = data;
		}
		document.querySelector(".js-alert-close").addEventListener('click', function (e) {
			html_alert.style.display = "none";
			console.log("hoi");
		});
	}

}


//#endregion

//#region ***  Callback-No Visualisation - callback___  ***
const callbackAddHoeveelheid = function (data) {
	if (data) {
		console.log('Vullen gelukt');
		document.querySelector('#add_hoeveelheid').value = '';
		getHistory();
	}
};

const callbackEditSettings = function (data) {
	if (data) {
		console.log('-- Settings editted');
		app_settings.daily_goal = data.daily_goal;
		app_settings.daily_range = data.daily_range;
		document.querySelector('#edit_daily_goal').value = data.daily_goal;
		document.querySelector('#edit_daily_range').value = data.daily_range;
	}
};

const callbackEditSettingsError = function (data) {
	console.log('Failed', data);
};

const callbackAppSettings = function (jsonObject) {
	app_settings = jsonObject;
	// console.log(jsonObject);

	if (app_settings) {
		showAppName();
		showDailyGoal();
		showDailyRange();
		showOpslag();
	}
};
//#endregion

//#region ***  Data Access - get___ ***
const getAppSettings = function () {
	handleData(`${backend}/app_settings`, callbackAppSettings);
};

const getMetingen = function () {
	handleData(`${backend}/metingen`, showMetingen);

};


const getHistory = function () {
	handleData(`${backend}/history`, showHistoryPet);
};

const getHistoryDay = function () {
	handleData(`${backend}/history/day`, showHistoryPetDay);
};

const getHistoryWeek = function () {
	handleData(`${backend}/history/week`, showHistoryPetWeek);
};

const getHistoryMonth = function () {
	handleData(`${backend}/history/month`, showHistoryPetMonth);
};

const getHistoryYear = function () {
	handleData(`${backend}/history/month`, showHistoryPetYear);
};

const getHistoryDate = function (date) {
	handleData(`${backend}/history/date/${date}`, showHistoryPetDay);
};

const getFillHistoryDay = function () {
	handleData(`${backend}/fillhistory/day`, showFillHistory);
}

const getFeedAverage = function (days) {
	handleData(`${backend}/feedaverage/${days}`, showFeedAverage);
};

const getFeedCountToday = function (days) {
	handleData(`${backend}/feedcount/${days}`, showFeedCountToday);
};

const getWijzigingen = function () {
	handleData(`${backend}/wijzigingen`, showWijzigingen);
};

const getEatenStatus = function (hoeveelheid) {
	let goal = parseInt(app_settings.daily_goal);
	let range = parseInt(app_settings.daily_range);

	let status = '';

	if (hoeveelheid >= goal + range * 2) {
		// status = 'way-too-much';
		status = "red"
	} else if (hoeveelheid < goal + range * 2 && hoeveelheid >= goal + range) {
		// status = 'too-much';
		status = "orange"
	} else if (
		hoeveelheid < goal + range &&
		(hoeveelheid >= goal || hoeveelheid <= goal) &&
		hoeveelheid > goal - range
	) {
		// status = 'normal';
		status = "green"
	} else if (hoeveelheid <= goal - range && hoeveelheid > goal - range * 2) {
		// status = 'too-little';
		status = "lightblue";
	} else if (hoeveelheid <= goal - range * 2) {
		// status = 'way-too-little';
		status = "blue"
	}

	return status;
};

const getDay = function (day_number) {
	let days = [
		'Zondag',
		'Maandag',
		'Dinsdag',
		'Woensdag',
		'Donderdag',
		'Vrijdag',
		'Zaterdag',

	];
	return days[day_number];
};

const getMonth = function (month_number) {
	let months = [
		'Januari',
		'Februari',
		'Maart',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Augustus',
		'September',
		'Oktober',
		'November',
		'Decemeber',
	];
	return months[month_number];
};

//#endregion

//#region ***  Event Listeners - listenTo___ ***
const listenToUI = function () { };

const listenToHoverOnDay = function () {
	let history_days = document.querySelectorAll('.js-feed-history-day');

	for (const day of history_days) {
		day.addEventListener('mouseover', function (e) {
			let date = getDay(new Date(day.dataset.date).getDay());
			let hoeveelheid = day.dataset.hoeveelheid;
			let info = document.querySelector('.js-feed-history-info');

			info.innerHTML = `Op ${date} ${hoeveelheid}g`;
		});
	}
};

const loadUIEventListeners = function () {
	document
		.querySelector('#btn_add_hoeveelheid')
		.addEventListener('click', function (e) {
			const jsonObject = {
				hoeveelheid: document.querySelector('#add_hoeveelheid').value,
			};
			console.log(jsonObject);
			handleData(
				`${backend}/add_hoeveelheid`,
				callbackAddHoeveelheid,
				null,
				'POST',
				JSON.stringify(jsonObject),
			);
			getFillHistoryDay();
			socket.emit("F2B_add_hoeveelheid", jsonObject);
		});

		document
		.querySelector('#btn_add_opslag')
		.addEventListener('click', function (e) {
			const jsonObject = {

				opslag: document.querySelector('#add_opslag').value,

				
			};
			console.log(jsonObject);
			// handleData(
			// 	`${backend}/add_hoeveelheid`,
			// 	callbackAddHoeveelheid,
			// 	null,
			// 	'POST',
			// 	JSON.stringify(jsonObject),
			// );
			// getFillHistoryDay();
			socket.emit("F2B_add_opslag", jsonObject);
		});

	document
		.querySelector('#btn_edit_settings')
		.addEventListener('click', function (e) {
			const jsonObject = {
				daily_goal: document.querySelector('#edit_daily_goal').value,
				daily_range: document.querySelector('#edit_daily_range').value,
			};
			console.log(jsonObject);
			handleData(
				`${backend}/app_settings`,
				callbackEditSettings,
				callbackEditSettingsError,
				'PUT',
				JSON.stringify(jsonObject),
			);
		});
	document
		.querySelector('.js-filter-today')
		.addEventListener('click', function (e) {
			``;
			getHistoryDay();
		});
	document
		.querySelector('.js-filter-week')
		.addEventListener('click', function (e) {
			``;
			getHistoryWeek();
		});
	document
		.querySelector('.js-filter-month')
		.addEventListener('click', function (e) {
			``;
			getHistoryMonth();
		});
	document
		.querySelector('.js-filter-year')
		.addEventListener('click', function (e) {
			``;
			getHistoryYear();
		});
	document
		.querySelector('.js-filter-all')
		.addEventListener('click', function (e) {
			``;

			getHistory();
		});

	document
		.querySelector('.js-filter-date-change')
		.addEventListener('click', function (e) {
			``;
			let date = document.querySelector(".js-filter-date").value;
			console.log(date);
			getHistoryDate(date);
		});

	let html_filter_date = document.querySelector(".js-filter-date");
	if (html_filter_date) {
		let today = new Date(new Date().setDate(new Date().getDate() - 2));
		let today_html = `${today.getFullYear()}-${("0" + (today.getMonth() + 1)).slice(-2)}-${("0" + (today.getDay() + 1)).slice(-2)}`;
		document.querySelector(".js-filter-date").value = today_html;
	}
};

const listenToSocket = function () {
	socket.on("connect", function () {
		console.log("Verbonden met socket webserver");
	});
	socket.on("B2F_food_eaten", function (data) {
		console.log(`Pet has eaten ${data}`);
	});
	socket.on("B2F_food_add", function () {
		console.log("Bowl has been filled");
	});
	socket.on("B2F_notification", function (data) {
		console.log(data);
		showAlert(data);
	});
	socket.on("B2F_feed_today", function (data) {
		let html_feed_today = document.querySelector(".js-feed-today");
		if (html_feed_today) {
			html_feed_today.innerHTML = `${data}g gegeten`;
		}
	});
	socket.on("B2F_current_weight_bowl", function (data) {
		//console.log(data);
		let html_current_feed = document.querySelector(".js-current-feed");
		if (html_current_feed) {
			html_current_feed.innerHTML = `${data} gram`;
		}
	});
	socket.on("B2F_current_weight_stock", function (data) {
		//console.log(data);
		let html_current_feed_stock = document.querySelector(".js-current-feed-stock");
		if (html_current_feed_stock) {
			html_current_feed_stock.innerHTML = `${data} gram`;
		}
	});
	socket.on("B2F_rgb", function (data) {
		// console.log(data);
		let html_notification = document.querySelectorAll(".js-notifications");
		for (let notification of html_notification) {
			if (notification) {
				notification.className = "js-notifications c-not "
				if (data == 1) {
					notification.className += "c-not-white";
					notification.innerHTML = "AAN";

				} else if (data == "red") {
					notificaiton.classList.add("c-not-red");
				}
				else if (data == "orange") {
					notificaiton.classList.add("c-not-orange");
				}
				else if (data == "green") {
					notificaiton.classList.add("c-not-green");
				}
				else if (data == "blue") {
					notificaiton.classList.add("c-not-green");
				}
				else if (data == 0) {
					notification.className += "c-not-black"
					notification.innerHTML = "UIT";

				}
			}
		}


	});


}

//#endregion

//#region ***  INIT / DOMContentLoaded  ***
const init = function () {
	console.log('SmartPET : Project : Maxime Vermeeren');
	toggleNav();
	html_page_dashboard = document.querySelector('.js-page-dashboard');
	html_page_metingen = document.querySelector('.js-page-metingen');
	listenToSocket();
	getAppSettings();

	if (html_page_dashboard) {

		html_feed_history = document.querySelector('.js-feed-history');
		html_fill_history = document.querySelector('.js-fill-history');
		html_wijzigingen = document.querySelector(".js-wijzigingen");

		loadUIEventListeners();

		if (html_feed_history) {
			getHistoryDay();
			getFeedAverage(30);
			getFeedCountToday(1);

		}

		if (html_fill_history) {
			getFillHistoryDay();
		}

		if(html_wijzigingen){
			getWijzigingen();
		}



	}
	if (html_page_metingen) {

		html_metingen = document.querySelector('.js-metingen');
		if (html_metingen) {
			getMetingen();
		}

	}



};

//#endregion

// ChartJS
const drawChart = function (labels, hoeveelheid_voederbak_data, label_x = "Dag", label_y = "Hoeveelheid in gram", bordercolor = "#3a44a0", type = "bar") {

	document.querySelector(".js-feed-history").innerHTML = `<canvas id="myChart" style="width:100%;height:250px;"></canvas>`;
	let ctx = document.querySelector('#myChart').getContext('2d');

	let config = {
		type: type, //Type chart
		data: {
			labels: labels, //Labels op de chart tonen
			datasets: [
				{
					label: 'Hoeveelheid dat is gegeten', //Hoofdlabel
					backgroundColor: 'rgba(0,0,0,0.05)',
					borderWidth: 1,
					borderColor: bordercolor,
					data: hoeveelheid_voederbak_data,
					fill: true,

				},

			],
		},
		options: {
			responsive: true,

			tooltips: {
				position: 'nearest',
				mode: 'index',
				intersect: false,
			},
			hover: {
				mode: 'nearest',
				intersect: true,
			},

			scales: {
				xAxes: [
					{
						display: true,
						scaleLabel: {
							display: true,
							labelString: label_x,

						},
						ticks: {
							// fontStyle: 'oblique',
							autoSkip: false,
							// maxRotation: 30,
							// minRotation: 30
						},


					},
				],
				yAxes: [
					{
						display: true,
						scaleLabel: {
							display: true,
							labelString: label_y,
						},
					},
				],
			},
		},
	};

	let myChart = new Chart(ctx, config);
	myChart.update();
};

document.addEventListener('DOMContentLoaded', init);
