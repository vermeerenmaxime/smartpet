<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="style/normalize.css" />
    <link rel="stylesheet" href="style/smartpet_screen.css"/>


    <script defer src="script/dataHandler.js"></script>
    <script defer src="script/app_mvp2.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>

    <title>SmartPET : Dashboard</title>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            toggleNav();
        })

        function toggleNav() {
            let toggleTrigger = document.querySelectorAll(".js-toggle-nav");
            for (let i = 0; i < toggleTrigger.length; i++) {
                toggleTrigger[i].addEventListener("click", function () {
                    console.log("Toggle Mobile Nav");
                    document.querySelector("body").classList.toggle("has-mobile-nav");
                })
            }
        }
    </script>
</head>

<body>
    <div class="c-page">
    <?php include('menu.html'); ?>
        <div class="o-row o-row--neutral-xx-light-linear u-pt-clear">
            
            <section class="o-row o-row--intro u-mb-xl u-mt-lg">
                <div class="o-container">
                    <article class="o-section">
                        <div class="o-layout o-layout--gutter o-layout--justify-center  o-layout--align-center">
                            <div class="o-layout__item u-1-of-3-bp3">
                                <div class="u-max-width-sm">
                                    <h2 class="c-lead c-lead--intro">Je huisdier controleren met een klik.</h2>
                                    <p>
                                        Voor elke kat of hond een automatisch eet-tracking dat uw dier gezond houdt.
                                    </p>
                                </div>
                            </div>
                            <div class="o-layout__item u-2-of-3-bp2">

                                <figure class="c-figure--intro">
                                    <img class="c-figure--intro"
                                        src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.freeiconspng.com%2Fuploads%2Fdog-family-png-11.png&f=1&nofb=1"
                                        alt="Honden">
                                </figure>
                            </div>
                        </div>
                    </article>
                </div>
            </section>
        </div>
        <section class="o-row o-row--neutral-xx-dark">
            <div class="o-container u-max-width-lg">
                <article class="o-section o-section-xl u-mt-xl u-mb-lg">
                    <div class="o-layout o-layout--gutter-lg o-layout--justify-center  o-layout--align-center">
                        <div class="o-layout__item u-1-of-2-bp3 u-mb-xl">
                            <div class="c-block">
                                <div class="u-max-width-lg">
                                    <div class="c-block__content ">
                                        <h2>History of your pet</h2>
                                        <p class="u-max-width-sm">
                                            Find the latest info about year pet in the history table. For more details
                                            about
                                            earlier, you can turn on a filter.
                                        </p>
                                        <h3>
                                            Filter on
                                        </h3>
                                        <button class="c-button js-filter-day selected">Last 24h</button>
                                        <button class="c-button js-filter-week">This week</button>
                                        <button class="c-button js-filter-month">Last month</button>
                                        <button class="c-button js-filter-year">Last year</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="o-layout__item u-1-of-2-bp3 u-mb-xl">
                            <canvas id="myChart" style="width:100%;height:350px;"></canvas>
                            <script>
                                var ctx = document.getElementById('myChart');
                                var myChart = new Chart(ctx, {
                                    type: 'bar',
                                    data: {
                                        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
                                        datasets: [{
                                            label: '# of Votes',
                                            data: [100, 19, 3, 5, 2, 3],
                                            backgroundColor: [
                                                'rgba(255, 99, 132, 0.2)',
                                                'rgba(54, 162, 235, 0.2)',
                                                'rgba(255, 206, 86, 0.2)',
                                                'rgba(75, 192, 192, 0.2)',
                                                'rgba(153, 102, 255, 0.2)',
                                                'rgba(255, 159, 64, 0.2)'
                                            ],
                                            borderColor: [
                                                'rgba(255, 99, 132, 1)',
                                                'rgba(54, 162, 235, 1)',
                                                'rgba(255, 206, 86, 1)',
                                                'rgba(75, 192, 192, 1)',
                                                'rgba(153, 102, 255, 1)',
                                                'rgba(255, 159, 64, 1)'
                                            ],

                                            borderWidth: 3
                                        }]
                                    },

                                    options: {
                                        legend: {
                                            labels: {
                                                fontColor: "white",
                                                fontSize: 18
                                            }
                                        },
                                        scales: {
                                            yAxes: [{
                                                ticks: {
                                                    fontColor: "white",
                                                    fontSize: 18,
                                                    stepSize: 1,
                                                    beginAtZero: true
                                                }
                                            }],
                                            xAxes: [{
                                                ticks: {
                                                    fontColor: "white",
                                                    fontSize: 14,
                                                    stepSize: 1,
                                                    beginAtZero: true,
                                                }
                                            }]
                                        }
                                    }
                                });
                            </script>
                            <!-- <div class="u-max-width-lg">
                            <div class="c-block">
                                <figure>
                                    <img src="https://i.imgur.com/mEq2MDn.jpg" alt="Grapfiek">
                                    
                                </figure>
                            </div>
                            </div> -->
                        </div>
                    </div>

                </article>
            </div>
        </section>
        <!-- <section class="o-row o-row--neutral-xx-light">
            <div class="o-container u-max-width-lg">
                <article class="o-section u-mt-xl">
                    <h2 class="c-lead">Latest meals</h2>
                </article>
                <article class="o-section u-mb-xl">
                    <div
                        class="o-layout o-layout--gutter-md o-layout--justify-left o-layout--align-center o-layout--row-reverse">
                        <div class="o-layout__item u-1-of-4-bp1 u-mb-xl">
                            <div class="c-block">
                                <div class="c-block__content">
                                    <h3 class="">Today at 23h23</h3>
                                    <p class="u-max-width-sm u-mb-sm">
                                        200g
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="o-layout__item u-1-of-4-bp1 u-mb-xl">
                            <div class="c-block">
                                <div class="c-block__content">
                                    <h3 class="">Today at 23h23</h3>
                                    <p class="u-max-width-sm u-mb-sm">
                                        200g
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="o-layout__item u-1-of-4-bp1 u-mb-xl">
                            <div class="c-block">
                                <div class="c-block__content">
                                    <h3 class="">Today at 23h23</h3>
                                    <p class="u-max-width-sm u-mb-sm">
                                        200g
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="o-layout__item u-1-of-4-bp1 u-mb-xl">
                            <div class="c-block">
                                <div class="c-block__content">
                                    <h3 class="">Today at 23h23</h3>
                                    <p class="u-max-width-sm u-mb-sm">
                                        200g
                                    </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </article>
            </div>
        </section> -->
        <?php include("footer.html"); ?>
    </div>
    <?php include("menu_aside.html"); ?>

</body>

</html>